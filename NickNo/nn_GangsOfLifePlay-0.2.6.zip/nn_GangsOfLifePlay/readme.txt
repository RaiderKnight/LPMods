Gangs of LifePlay: KingPin ReadMe, Change Log and TODO List
=============================================================

ReadMe
********

Gangs of LifePlay is a mod that extends the 'crime' options of LifePlay.
As the name suggests your plan is to rule the world and become the kingpin 
(leader) of the crime scene.

Your objective is simple: Earn money and gain power by running your crime busines!

Stats that influence gameplay
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The following paragrap is intentionally kept short. 
Usually you should find out yourself, so only read, if you fail to succeed!

- Locks can be broken if your lock picking skill is high enough
- Doors can be kicked open if you are strong enough
- Fitness and muscle is used for fighting. 
- Martial stat is used to decide if you hit your target in melee fights
- If you buy a knife or baseball bat your martial states will be even better
- A baseball bat will give you a range bonus
- A gun will help you fight if you are low on health or energy - or anything else!
- Gun skill determines your shooting precision

Actions
~~~~~~~~

Train pistol skills (Crime Menu)
- Available everywhere from 10:00-16:00. Costs 100 Money and 15 energy. Gives 2 hand gun skill points.

Learn lock picking
- Available everywhere if you have enough energy. Increases your lock picking skill by 2.

Show stolen goods 'inventory'
- Always available. Show your inventory of stolen goods.

Deal drugs
- Sell drugs to ppl on the street 

Visit the black market 
- Available everywhere or on your PC. Access the black market to trade stuff.

Sell drugs on the BM
- Bulk sell drugs on the black market. (If available)

Flog 'aquired' items
- Bulk sell your valuable items on the black market. (If available)

Break into the storage room (At hospital)
- Chance to be caught is 60%. If your sneaking skill is > 60 you won't be caught at all.
- Can use martial, muscle, knife, baseball bat or gun when caught
- Can get a pistol when the security has one and you manage to knock him/her out
- Player can get killed when caught and attacking an armed security
- Player can go to jail when caught

Change Log
************
Version 0.2 (19.01.2021):
- Sneak game from door unlocking removed (did not work correctly)
- Added option to kick doors open if enough muscle
- Renamed "Deal Drugs" to "Sell drugs on BM"
- Added new "Deal Drugs" scene with dealer popularity etc
- 3D scene for street added
- "Deal Drugs" happens on the new 3D street
  -> The scene is WIP as I need to wait for LP 3.19 (API requests)
- Break into storage room at: hospital, pharmacy, doctor, veterinary
  -> Will give more pills than other stuff
- Break into storage room at: mobile_phone, photo, jewellery, electronics, computer
  -> Will give more items and cash than other stuff
  -> New 3D Scene for security encounters


Version 0.1 (17.01.2021):
- Initial release


TODOs (Planned features by NickNo)
************************************
Developer
- Add silencer
- Add gang members
- Add drug dealers
- Add street hookers
- Add handlers
- use knock out animation as soon as it gets available
- add bullet proof vest

PRIO 1

PRIO 2
- Add Quests


PRIO 3
- Add some sort of competitors

Feature Requests (Requested by others)
****************************************

LifePlay Patrons will be served first!

REQEST: Example request
FROM: NickNo (Discord)


Developer & Tester Notes
**************************

To open the debug menu press the # key and type:
nn_gl_debug + return