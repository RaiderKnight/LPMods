Mod: Home Assignment
https://f95zone.to/threads/11321/post-6245281

This mod adds an "Assign Home" action to the PC menu which allows you to assign homes to NPCs. This is primarily for role-playing/immersion purposes. You can use it to move couples/families into the same home, or move friends/partners into homes closer to yours so you don't have to travel hours away to get to them.


How it Works:
You must be in the Home building that you want to move the NPC(s) into, and the home cannot be yours or your partner's. Once you're inside the home, use the action and it'll open up a menu where you select and confirm the NPC you want to move into this home. They'll then move into that home from wherever else they were living. You can do this multiple times for different NPCs to move them into the same home.

Whenever you assign a home to somebody it'll add a marker for that home on the map similar to the one that gets added for a person you are dating. A side effect of this which may be considered a bonus to some people is that the home will from then on allow all of the same actions you could normally do at your home or your partner's home. I realize that the markers/opened up homes might be unwanted by some people, so I've added the ability to toggle this on and off. To toggle the adding of markers, hit the ~ key and in the textbox at the bottom right of the screen enter toggle_home_markers. This will enable/disable adding new markers depending on the current state. It will not hide existing markers on the map, but you can remove those manually the same as any other marker.


Installation:
Unzip the archive in your Modules directory and activate the mod with the in-game mod manager


Known Issues:
    - This doesn't currently work with relatives. I'm still looking for a way of handling them.
    - Using this action will reset the look of your bedroom, so make sure you've saved a preset of it that you can reload after you're done moving people.

    Home Markers:
    - The marker will only contain the NPCs first name, so it may get confusing if you move multiple NPCs with the same name into different homes.
    - If you move multiple NPCs into the same home, the marker will only show the name of the last person you moved in.
    - If you have multiple NPCs living in the same home, and you move one of them to another home, the previous home will no longer be marked even though there's still other NPCs living in it. Move one of the remaining NPCs into the home again using the action if you want the home to be marked again.
    - If you move somebody into a home with markers enabled, disable the markers, and then decide to move another NPC into that same home, the marker for that home will disappear.

Changelog:
25/07/21
Updated to work correctly if you don't have a home or if you're with a companion, and to fix some other weird issues.

02/08/21
Bugfixes

15/08/21
Map markers now get added for homes that you assign people to. Credit to straydogg for the idea.
