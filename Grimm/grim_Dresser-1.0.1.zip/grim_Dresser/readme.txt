Mod: Dresser
https://f95zone.to/threads/11321/post-7665258

This mod adds a "Dresser" interaction to companions which allows you to select their clothing, generate a random outfit, or make them nude.


How it Works:
Click on your companion and select the Dresser interaction. The background will change to a well lit "dressing room" and you'll be presented with a menu that's self-explanatory. The "Pick Clothing" option will present a number of clothing categories which are labeled by which clothing slot(s) they occupy. You can only equip one clothing item in each slot, and some clothing takes up multiple slots. Selected clothing for slots that are already occupied will remove/replace whatever clothing currently occupies it. There's also a "Remove" option in each category which simply removes whatever clothing is currently in the slot(s) without replacing it with anything. The "Bottom" slot cannot be removed (See Known Issues for details). Clothing color cannot be specified, but you can select the same item multiple times to change the color. Once you're done picking clothing select the "Finished" option at the bottom of any menu to close the menu and return to your previous location.

If you want underwear to be visible under clothing then you need to enable the "Underwear Visible Under Clothes" setting in the game settings. Otherwise it'll only be visible if the outer layer of clothing (Top and/or Bottom) is removed. Because of the aforementioned issue with the Bottom slot, this means panties, boxers, etc. will never be visible unless the visibility setting is enabled.

Avoid using the "Emergency!" button while using the Dresser interaction. The mod does some cleanup when the normal "Finished" button is used, and the emergency button bypasses this which will cause issues with the mod. Use the Dresser interaction again and hit Finished to correct this.

This mod does not currently allow you to save outfits. The outfit only sticks for as long as you're with your companion. I have an idea for how outfit saving could be accomplished but it will require further testing to see if it's feasible.


Installation:
1. Unzip the archive in your Modules directory.
2. Copy Clothes4.txt from the grim_Dresser directory to the Modules directory and overwrite the original file.
2. Activate the mod with the in-game mod manager.


Known Issues:
- TLDR: You can't remove the bottom of the outfit. Issue with the game itself.
  Details: It's not currently possible to remove the Bottom slot of the outfit without causing issues, and the mod intentionally prevents the slot from ever being empty by adding a placeholder item to it if your selection would cause it to be empty. Whenever the game detects that the Bottom slot is empty, it seems to force the actor to redress when the scene ends, even if you ultimately end up equipping something in that slot. The forced redress can mess up other parts of the outfit you've already configured. The description of setNoRedress() implies that it's the solution to this, but it seems to have a bug which causes the actor to remove all of their clothes instead, making it not much different than strip() except that it persists after the scene ends.
- The "Nude" option in the main menu prevents you from permanently equipping anything afterwards. Use the "Random" option to reset this if you wish to select clothing again.
- The mod can't accurately track what the NPC is wearing once you leave the dressing room. This means that the protections in place to prevent the bottom slot from ever being empty will no longer work correctly. Don't rely on them to prevent the outfit from getting messed up and assume that you'll be starting a new outfit from scratch.
- The male Accessory slot can't be removed. Seems to be an issue with the stripOne() function.
- Sometimes the NPC doesn't face the direction of the initial camera position.
